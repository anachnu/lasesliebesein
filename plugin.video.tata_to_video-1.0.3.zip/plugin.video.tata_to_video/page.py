#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcaddon,urllib,sys,os,re,base64,request,player

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')

folder_icon = os.path.join(addon_path,'folder.png')
search_icon = os.path.join(addon_path,'search.png')
next_page_icon = os.path.join(addon_path,'next.png')

def addDir(name,url,mode,iconimage):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)
    liz=xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo( type='video', infoLabels={ 'Title': name } )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)

def next_page(content):
    match = re.search('<nav[^<>]*class="page-nav"[^<>]*>[\s\S]*?<\/nav>',content,re.DOTALL)
    if match:
        match = re.search('<a*[^<]*rel="next">',match.group(0),re.DOTALL)
        if match:
            match = re.search('href="(.*?)".*?page="(.*?)"',match.group(0),re.DOTALL)
            if match:
                addDir('[COLOR red]NEXT PAGE ' + match.group(2) + ' >>[/COLOR]',match.group(1),0,next_page_icon)

def regex_s1(content):
    for url,img,title in re.findall('<div[^<>]*class="ml-item-content"[^<>]*>[\s\S]*?href="(.*?)"[^<>]*>[\s\S]*?src="(.*?)"[^<>]*>[\s\S]*?<h6>([^<>]*)<\/h6>',content,re.DOTALL):
        addDir(title.strip(),url,1,img)
    next_page(content)

def regex_s2_play_url(content):
    match = re.search("<div[^>]*data-url='(.*?)'", content,re.DOTALL)
    if match:
        decode_content = base64.decodestring(request.requesthandler(match.group(1)))
        match = re.search('playinfo":"(.*?)&', decode_content,re.DOTALL)
        if match:
            return match.group(1).replace('\/', '/').replace('embed.html', 'index.m3u8') + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1'

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                         
        return param		
params=get_params()

url=None
name=None
mode=None
iconimage=None

try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode=int(params["mode"])
except:
    pass

if mode == None: 
    addDir('Neuste','https://www.tata.to/filme?type=alle&order=neueste',0,folder_icon)
    addDir('Am häufigsten gesehen','https://www.tata.to/filme?type=alle&order=ansichten',0,folder_icon)
    addDir('Am meisten bewertet','https://www.tata.to/filme?type=alle&order=ratingen',0,folder_icon)
    addDir('Top IMDb','https://www.tata.to/filme?type=alle&order=imdb',0,folder_icon)
    addDir('Veröffentlichungsdatum','https://www.tata.to/filme?type=alle&order=ver%C3%B6ffentlichung',0,folder_icon)
    addDir('Alphabetisch','https://www.tata.to/filme?type=alle&order=alphabetisch',0,folder_icon)
    addDir('Alle','https://www.tata.to/filme?type=alle&order=alle',0,folder_icon)
    addDir('Abenteuer','https://www.tata.to/genre/abenteuer-filme?type=alle&order=alle',0,folder_icon)
    addDir('Action','https://www.tata.to/genre/action-filme?type=alle&order=alle',0,folder_icon)
    addDir('Animation','https://www.tata.to/genre/animation-filme?type=alle&order=alle',0,folder_icon)
    addDir('Dokumentar','https://www.tata.to/genre/dokumentarfilm-filme?type=alle&order=alle',0,folder_icon)
    addDir('Drama','https://www.tata.to/genre/drama-filme?type=alle&order=alle',0,folder_icon)
    addDir('Familie','https://www.tata.to/genre/familie-filme?type=alle&order=alle',0,folder_icon)
    addDir('Fantasy','https://www.tata.to/genre/fantasy-filme?type=alle&order=alle',0,folder_icon)
    addDir('Foreign','https://www.tata.to/genre/foreign-filme?type=alle&order=alle',0,folder_icon)
    addDir('Historie','https://www.tata.to/genre/historie-filme?type=alle&order=alle',0,folder_icon)
    addDir('Horror','https://www.tata.to/genre/horror-filme?type=alle&order=alle',0,folder_icon)
    addDir('Komoedie','https://www.tata.to/genre/komoedie-filme?type=alle&order=alle',0,folder_icon)
    addDir('Krieg','https://www.tata.to/genre/kriegsfilm-filme?type=alle&order=alle',0,folder_icon)
    addDir('Krimi','https://www.tata.to/genre/krimi-filme?type=alle&order=alle',0,folder_icon)
    addDir('Love','https://www.tata.to/genre/lovestory-filme?type=alle&order=alle',0,folder_icon)
    addDir('Musik','https://www.tata.to/genre/musik-filme?type=alle&order=alle',0,folder_icon)
    addDir('Mystery','https://www.tata.to/genre/mystery-filme?type=alle&order=alle',0,folder_icon)
    addDir('Science-Fiction','https://www.tata.to/genre/science-fiction-filme?type=alle&order=alle',0,folder_icon)
    addDir('TV-Filme','https://www.tata.to/genre/tv-film-filme?type=alle&order=alle',0,folder_icon)
    addDir('Thriller','https://www.tata.to/genre/thriller-filme?type=alle&order=alle',0,folder_icon)
    addDir('Western','https://www.tata.to/genre/western-filme?type=alle&order=alle',0,folder_icon)
    addDir('[COLOR red]Suche ???[/COLOR]','',2,search_icon)

if mode == 0:
    content = request.requesthandler(url)	
    regex_s1(content)

if mode == 1:
    content = request.requesthandler(url)
    play_url = regex_s2_play_url(content)
    player.play(play_url, name, iconimage)

if mode == 2:
        keyboard = xbmc.Keyboard()
        keyboard.setHeading('Search Movies')
        keyboard.setDefault('')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
           search_url = urllib.unquote_plus('https://www.tata.to/filme?type=alle&order=alle&suche=' + str(keyboard.getText()).strip() + '*')
           content = request.requesthandler(search_url)	
           regex_s1(content)

xbmcplugin.endOfDirectory(int(sys.argv[1]))